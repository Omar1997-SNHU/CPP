#include <iostream>
#include <iomanip>
#include <cmath>
#include <stdexcept>
#include <limits>

using namespace std;

class InvestmentCalculator {
private:
    double initialAmount;
    double monthlyDeposit;
    double annualInterest;
    int years;

    // Validate all inputs rules
    void ValidateInputs() {
        if (initialAmount < 0) {
            throw invalid_argument("Initial investment cannot be negative");
        }
        if (monthlyDeposit < 0) {
            throw invalid_argument("Monthly deposit cannot be negative");
        }
        if (annualInterest < 0 || annualInterest > 100) {
            throw invalid_argument("Interest rate must be between 0-100%");
        }
        if (years < 1) {
            throw invalid_argument("Investment period must be at least 1 year");
        }
    }

    // Display formatted yearly investment report
    void DisplayYearlyReport(int year, double balance, double interest) {
        cout << year << "\t\t$"
            << fixed << setprecision(2)
            << balance << "\t\t$"
            << interest << endl;
    }

public:
    // Constructor with input validation
    InvestmentCalculator(double init, double deposit, double interest, int yrs)
        : initialAmount(init), monthlyDeposit(deposit),
        annualInterest(interest), years(yrs) {
        ValidateInputs();
    }

    // Calculate and display growth without monthly deposits
    void CalculateWithoutMonthlyDeposits() {
        double balance = initialAmount;
        double monthlyRate = annualInterest / 1200.0;

        cout << "\nYear\t\tBalance\t\tInterest Earned\n";
        cout << "---------------------------------------------\n";

        for (int year = 1; year <= years; year++) {
            double startingBalance = balance;

            // Calculate monthly compound interest
            for (int month = 1; month <= 12; month++) {
                balance *= (1 + monthlyRate);
            }

            // Round to two decimal places
            balance = round(balance * 100) / 100;
            double yearlyInterest = balance - startingBalance;

            DisplayYearlyReport(year, balance, yearlyInterest);
        }
    }

    // Calculate and display growth with monthly deposits
    void CalculateWithMonthlyDeposits() {
        double balance = initialAmount;
        double monthlyRate = annualInterest / 1200.0;

        cout << "\nYear\t\tBalance\t\tInterest Earned\n";
        cout << "---------------------------------------------\n";

        for (int year = 1; year <= years; year++) {
            double startingBalance = balance;
            double yearlyInterest = 0.0;

            for (int month = 1; month <= 12; month++) {
                // Add deposit at start of month (except first month)
                if (month > 1 || year > 1) {
                    balance += monthlyDeposit;
                }

                // Calculate and add monthly interest
                double monthlyInterest = balance * monthlyRate;
                yearlyInterest += monthlyInterest;
                balance += monthlyInterest;
            }

            // Round to two decimal places
            balance = round(balance * 100) / 100;
            yearlyInterest = round(yearlyInterest * 100) / 100;

            DisplayYearlyReport(year, balance, yearlyInterest);
        }
    }
};

// Get validated user input
double GetValidatedInput(const string& prompt, bool allowZero = true) {
    double input;
    while (true) {
        cout << prompt;
        cin >> input;

        if (cin.fail() || (input < 0 && !allowZero) || (input <= 0 && !allowZero)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "Invalid input. Please enter a positive value: ";
        }
        else {
            break;
        }
    }
    return input;
}

int main() {
    try {
        cout << "**********************************************\n";
        cout << "*********** AIRGEAD BANKING INVESTMENT ***********\n";
        cout << "**********************************************\n\n";

        // Get user input with validation
        double initialAmount = GetValidatedInput("Enter initial investment amount: $", false);
        double monthlyDeposit = GetValidatedInput("Enter monthly deposit amount: $");
        double annualInterest = GetValidatedInput("Enter annual interest rate (%): ");
        int years = static_cast<int>(GetValidatedInput("Enter number of years: ", false));

        // Create calculator instance
        InvestmentCalculator calculator(initialAmount, monthlyDeposit, annualInterest, years);

        // Display results
        cout << "\n\nCOMPOUND INTEREST CALCULATOR RESULTS\n";
        calculator.CalculateWithoutMonthlyDeposits();
        calculator.CalculateWithMonthlyDeposits();

        cout << "\nThank you for using Airgead Banking Investment Calculator!\n";

    }
    catch (const exception& e) {
        cerr << "\nERROR: " << e.what() << endl;
        return 1;
    }

    return 0;
}